package com.capgemini.tests;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.capgemini.driversetup.SetupDriver;
import com.capgemini.pages.FD_FindDoctors;
import com.capgemini.pages.FD_InternalFiltersPage;
import com.capgemini.pages.Loginpracto;
import com.capgemini.parameters.ExcelReader;
import com.capgemini.utils.Screenshots;

public class FD_005 extends BaseReport {
	WebDriver driver;
	Loginpracto lptest;
	FD_FindDoctors Doctors;
	FD_InternalFiltersPage internalFilters;
	String screenshotPath;
	WebDriverWait wait;
	String excelPath;

	@BeforeClass
	public void setUp() {
		// Set path to chromedriver if not in system PATH

		driver = SetupDriver.getDriver("chrome");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.practo.com/");
		lptest = new Loginpracto(driver);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Doctors = new FD_FindDoctors(driver);
		internalFilters = new FD_InternalFiltersPage(driver);
		excelPath = "src/test/resources/ExcelData/Book1.xlsx";
	}

	/*
	 * Created By : Anjali Gajula Reviewed By : Richa Singh Test scenario: Verifying
	 * whether the user can find the doctors based on applying filters
	 */

	@Test
	public void testLogin() throws Exception {
		String phonenum = ExcelReader.getCellData(excelPath, "login", 0, 0);
		String pass = ExcelReader.getCellData(excelPath, "login", 0, 1);

		// Click on Login
		WebElement loginBtn = lptest.getLogin();
		wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login", screenshotPath);

		// Enter the valid mobile number
		WebElement phoneInput = lptest.getLogNum();
		if (phoneInput.isDisplayed()) {
			test.pass("Login Number is Visisble");
			Assert.assertTrue(true);
		} else {
			test.fail("Login Number is not Visisble");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.visibilityOf(phoneInput)).sendKeys(phonenum);
		screenshotPath = Screenshots.takeScreenShot(driver, "Numberasinput");
		generateReportWithScreenshot("Clicked on Login Number", screenshotPath);

		// Enter the Valid Password
		WebElement passwordInput = lptest.getLogPass();
		if (passwordInput.isDisplayed()) {
			test.pass("Password field is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Password field is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.visibilityOf(passwordInput)).sendKeys(pass);
		screenshotPath = Screenshots.takeScreenShot(driver, "Password");
		generateReportWithScreenshot("Clicked on password", screenshotPath);

		// Click on Login Button for submit
		WebElement loginSubmit = lptest.getButton();
		if (loginSubmit.isDisplayed()) {
			test.pass("Login button is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Login button is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(loginSubmit)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "ButtonClicked");
		generateReportWithScreenshot("Clicked on submit button", screenshotPath);
	}

	@Test(dependsOnMethods = "testLogin")
	public void DoctorFilters() throws Exception {

		// Click on Find Doctors which will navigate to the next page
		WebElement findDoctorsBtn = Doctors.getFindDoctors();
		wait.until(ExpectedConditions.elementToBeClickable(findDoctorsBtn)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "FindDoctorClicked");
		generateReportWithScreenshot("Clicked on find Doctors", screenshotPath);

		// Click on the Location Placeholder
		WebElement location = Doctors.getLocation();
		wait.until(ExpectedConditions.elementToBeClickable(location)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "GetlocationClicked");
		generateReportWithScreenshot("Clicked on Location", screenshotPath);

		// Take city from the drop down list
		WebElement city = Doctors.getCity();
		wait.until(ExpectedConditions.elementToBeClickable(city)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "GetCityClicked");
		generateReportWithScreenshot("Clicked on City", screenshotPath);

		// Search for Doctor through placeholder and it will navigate to the next page
		WebElement specialist = Doctors.getSpecilselector();

		wait.until(ExpectedConditions.elementToBeClickable(specialist)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "SpecialistClicked");
		generateReportWithScreenshot("Clicked on Doctor", screenshotPath);

		// Apply the gender filter displayed on the page
		WebElement filters = internalFilters.getGenderSelect();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", filters);
		screenshotPath = Screenshots.takeScreenShot(driver, "GenderSelected");
		generateReportWithScreenshot("Clicked on Gender Filter", screenshotPath);

		// Click on Patient story filter to get the drop down list
		WebElement patientstory = internalFilters.getPatientStoriesDrop();

		wait.until(ExpectedConditions.elementToBeClickable(patientstory)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "PatientStoriesDropdown");
		generateReportWithScreenshot("Clicked on Patient Stories Dropdown", screenshotPath);

		// Apply the Patient Stories filter displayed
		WebElement storieseelect = internalFilters.getStoriesSelect();
		js.executeScript("arguments[0].click();", storieseelect);
		screenshotPath = Screenshots.takeScreenShot(driver, "PatientStoriesSelected");
		generateReportWithScreenshot("Selected Patient Stories Filter", screenshotPath);

		// Click on Experience filter to get the drop down list
		WebElement Experience = internalFilters.getExperience();
		wait.until(ExpectedConditions.elementToBeClickable(Experience)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "ExperienceDropdown");
		generateReportWithScreenshot("Clicked on Experience Dropdown", screenshotPath);

		// Apply the experience filter as per requirement
		WebElement experience = internalFilters.getExperienceSelect();
		wait.until(ExpectedConditions.elementToBeClickable(experience)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "ExperienceSelected");
		generateReportWithScreenshot("Selected Experience Filter", screenshotPath);

		// Click on contact Clinic and the number will be displayed to contact
		WebElement clinic = internalFilters.getContactClinic();
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(clinic)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "ContactClinicClicked");
		generateReportWithScreenshot("Clicked on Contact Clinic", screenshotPath);
	}

	@AfterClass(alwaysRun = true)

	public void tearDownMethod() {
		if (driver != null) {
			driver.quit();
			Reporter.log("Browser closed after test method", true);
		}
	}
}
