package com.capgemini.tests;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.capgemini.driversetup.SetupDriver;
import com.capgemini.pages.FD_FindDoctors;
import com.capgemini.pages.FD_HomePage;
import com.capgemini.pages.FD_InternalFiltersPage;
import com.capgemini.pages.Loginpracto;
import com.capgemini.parameters.ExcelReader;
import com.capgemini.utils.Screenshots;

public class FD_003 extends BaseReport {
	WebDriver driver;
	Loginpracto lptest;
	FD_FindDoctors Doctors;
	FD_HomePage page;
	FD_InternalFiltersPage filters;
	String screenshotPath;
	WebDriverWait wait;
	String excelPath;

	@BeforeClass
	public void setUp() {
		// Set path to chromedriver if not in system PATH

		driver = SetupDriver.getDriver("chrome");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.practo.com/");
		lptest = new Loginpracto(driver);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Doctors = new FD_FindDoctors(driver);
		filters = new FD_InternalFiltersPage(driver);
		excelPath = "src/test/resources/ExcelData/Book1.xlsx";
	}

	/*
	 * Created By : Anjali Gajula Reviewed By : Richa Singh Test scenario: Verifying
	 * whether the user can find the details of the doctor
	 * 
	 */

	@Test
	public void testLogin() throws Exception {
		String phonenum = ExcelReader.getCellData(excelPath, "login", 0, 0);
		String pass = ExcelReader.getCellData(excelPath, "login", 0, 1);
		// Click on Login
		WebElement loginBtn = lptest.getLogin();
		wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login", screenshotPath);

		// Enter the valid mobile number
		WebElement phoneInput = lptest.getLogNum();
		if (phoneInput.isDisplayed()) {
			test.pass("Login Number is Visisble");
			Assert.assertTrue(true);
		} else {
			test.fail("Login Number is not Visisble");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.visibilityOf(phoneInput)).sendKeys(phonenum);
		screenshotPath = Screenshots.takeScreenShot(driver, "Numberasinput");
		generateReportWithScreenshot("Clicked on Login Number", screenshotPath);

		// Enter the Valid Password
		WebElement passwordInput = lptest.getLogPass();
		if (passwordInput.isDisplayed()) {
			test.pass("Password field is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Password field is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.visibilityOf(passwordInput)).sendKeys(pass);
		screenshotPath = Screenshots.takeScreenShot(driver, "Password");
		generateReportWithScreenshot("Clicked on password", screenshotPath);

		// Click on Login Button for submit
		WebElement loginSubmit = lptest.getButton();
		if (passwordInput.isDisplayed()) {
			test.pass("Login button is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Login button is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(loginSubmit)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "ButtonClicked");
		generateReportWithScreenshot("Clicked on submit", screenshotPath);
	}

	@Test(dependsOnMethods = "testLogin")
	public void Doctordetails() throws Exception {

		// Click on Find Doctors which will navigate to the next page
		WebElement findDoctorsBtn = Doctors.getFindDoctors();
		if (findDoctorsBtn.isDisplayed()) {
			test.pass("find Doctors button is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("find Doctors button is not visible");
			Assert.assertTrue(false);
		}
		wait.until(ExpectedConditions.elementToBeClickable(findDoctorsBtn)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "FindDoctorClicked");
		generateReportWithScreenshot("Clicked on find Doctors", screenshotPath);

		// Click on the Location Placeholder
		WebElement location = Doctors.getLocation();
		if (location.isDisplayed()) {
			test.pass("location placeholder is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("location placeholder is not visible");
			Assert.assertTrue(false);
		}
		wait.until(ExpectedConditions.elementToBeClickable(location)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "GetlocationClicked");
		generateReportWithScreenshot("Clicked on Location", screenshotPath);

		// Take city from the drop down list
		WebElement city = Doctors.getCity();
		if (city.isDisplayed()) {
			test.pass("city entered successfully");
			Assert.assertTrue(true);
		} else {
			test.fail("city not entered successfully");
			Assert.assertTrue(false);
		}
		wait.until(ExpectedConditions.elementToBeClickable(city)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "GetCityClicked");
		generateReportWithScreenshot("Clicked on City", screenshotPath);

		// Search for Doctor through placeholder and it will navigate to the next page
		WebElement specialist = Doctors.getSpecilselector();
		if (specialist.isDisplayed()) {
			test.pass("specialization placeholder is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("specialization placeholder is not visible");
			Assert.assertTrue(false);
		}
		wait.until(ExpectedConditions.elementToBeClickable(specialist)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "SpecialistClicked");
		generateReportWithScreenshot("Clicked on Doctor", screenshotPath);

		// using handles to handle the pages
		String handle = driver.getWindowHandle();

		// Click on Doctor details it will navigate to the doctor details page
		WebElement doctorDetails = filters.Doctors_details();
		if (doctorDetails.isDisplayed()) {
			test.pass("Doctors details is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Doctors details is not visible");
			Assert.assertTrue(false);
		}
		wait.until(ExpectedConditions.elementToBeClickable(doctorDetails)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "DoctordetailsClicked");
		generateReportWithScreenshot("Clicked on Doctors Details", screenshotPath);

		for (String win : driver.getWindowHandles()) {
			if (!win.equals(handle)) {
				driver.switchTo().window(win);
			}
		}
		screenshotPath = Screenshots.takeScreenShot(driver, "DoctordetailsClicked");
		generateReportWithScreenshot("Clicked on Doctors Details", screenshotPath);
	}

	@AfterClass(alwaysRun = true)

	public void tearDownMethod() {

		if (driver != null) {

			driver.quit();

			Reporter.log("Browser closed after test method", true);

		}

	}

}
