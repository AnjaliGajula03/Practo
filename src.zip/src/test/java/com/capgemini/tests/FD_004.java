package com.capgemini.tests;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.capgemini.driversetup.SetupDriver;
import com.capgemini.pages.FD_FindDoctors;
import com.capgemini.pages.FD_HomePage;
import com.capgemini.pages.FD_InternalFiltersPage;
import com.capgemini.pages.Loginpracto;
import com.capgemini.pages.patientDetails;
import com.capgemini.parameters.ExcelReader;
import com.capgemini.utils.Screenshots;

public class FD_004 extends BaseReport {
	WebDriver driver;
	Loginpracto lptest;
	FD_FindDoctors Doctors;
	FD_HomePage findDoctors;
	patientDetails patientform;
	String screenshotPath;
	FD_InternalFiltersPage internalFilters;
	WebDriverWait wait;
	String excelPath;

	@BeforeClass
	public void setUp() {
		driver = SetupDriver.getDriver("chrome");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.practo.com/");
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		lptest = new Loginpracto(driver);
		Doctors = new FD_FindDoctors(driver);
		internalFilters = new FD_InternalFiltersPage(driver);
		excelPath = "src/test/resources/ExcelData/Book1.xlsx";
	}

	/*
	 * Created By : Anjali Gajula Reviewed By : Richa Singh Test scenario: Verifying
	 * whether the user is able to find the doctors through the relevant
	 * specialization
	 */
	@Test
	public void testLogin() throws Exception {
		String phonenum = ExcelReader.getCellData(excelPath, "login", 0, 0);
		String pass = ExcelReader.getCellData(excelPath, "login", 0, 1);
		// Click on Login
		WebElement loginBtn = lptest.getLogin();
		wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "LoginButtonClicked");
		generateReportWithScreenshot("Clicked on Login", screenshotPath);

		// Enter the valid mobile number
		WebElement phoneInput = lptest.getLogNum();
		if (phoneInput.isDisplayed()) {
			test.pass("Login Number is Visisble");
			Assert.assertTrue(true);
		} else {
			test.fail("Login Number is not Visisble");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.visibilityOf(phoneInput)).sendKeys(phonenum);
		screenshotPath = Screenshots.takeScreenShot(driver, "Numberasinput");
		generateReportWithScreenshot("Clicked on Login Number", screenshotPath);

		// Enter the Valid Password
		WebElement passwordInput = lptest.getLogPass();
		if (passwordInput.isDisplayed()) {
			test.pass("Password field is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Password field is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.visibilityOf(passwordInput)).sendKeys(pass);
		screenshotPath = Screenshots.takeScreenShot(driver, "Password");
		generateReportWithScreenshot("Clicked on password", screenshotPath);

		// Click on Login Button for submit
		WebElement loginSubmit = lptest.getButton();
		if (passwordInput.isDisplayed()) {
			test.pass("Login button is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Login button is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(loginSubmit)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "ButtonClicked");
		generateReportWithScreenshot("Clicked on find Doctors", screenshotPath);
	}

	@Test(dependsOnMethods = "testLogin")
	public void popularSearch() throws Exception {

		// Click on Find Doctors which will navigate to the next page
		WebElement findDoctorsBtn = Doctors.getFindDoctors();
		if (findDoctorsBtn.isDisplayed()) {
			test.pass("find Doctors button is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("find Doctors button is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(findDoctorsBtn)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "FindDoctorClicked");
		generateReportWithScreenshot("Clicked on find Doctors", screenshotPath);

		// Click on Others displayed in the popular search section
		WebElement popularSearch = Doctors.getPopularSearch_others();
		if (popularSearch.isDisplayed()) {
			test.pass("Popular Search option with others is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Popular Search option with others is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(popularSearch)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "PopularSearchClicked");
		generateReportWithScreenshot("Clicked on PopularSearch", screenshotPath);

		// Select the specialization then it will navigate to next page
		WebElement dentistOption = Doctors.getSelect_dentist();
		if (dentistOption.isDisplayed()) {
			test.pass("dentist is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("dentist is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(dentistOption)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "SpecializationClicked");
		generateReportWithScreenshot("Clicked on Dentist", screenshotPath);

		// Click on Book Clinic
		WebElement bookClinic = internalFilters.getBookClinic_Visit();
		if (bookClinic.isDisplayed()) {
			test.pass("book clinic button is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("book clinic button is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(bookClinic)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "BookClinicClicked");
		generateReportWithScreenshot("Clicked on BookClinicVisit", screenshotPath);

		// Click on Slot
		WebElement slot = internalFilters.getSlot();
		if (findDoctorsBtn.isDisplayed()) {
			test.pass("Slot is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("Slot is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(slot)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "SlotTimeClicked");
		generateReportWithScreenshot("Clicked on Slot Time", screenshotPath);

		// Select the required time slot
		WebElement slot_Time = internalFilters.getSlot_Time();
		if (slot_Time.isDisplayed()) {
			test.pass("slot_Time is visible");
			Assert.assertTrue(true);
		} else {
			test.fail("slot_Time is not visible");
			Assert.fail("test fail");
		}
		wait.until(ExpectedConditions.elementToBeClickable(slot_Time)).click();
		screenshotPath = Screenshots.takeScreenShot(driver, "SlotTimeClicked");
		generateReportWithScreenshot("Clicked on Slot Time", screenshotPath);

		Thread.sleep(5000);
		screenshotPath = Screenshots.takeScreenShot(driver, "SlotTimeClicked");
		generateReportWithScreenshot("Clicked on Slot Time", screenshotPath);
	}

	// Click on Submit button and the appointment is confirmed
//        WebElement submitBtn = patientform.getClick_Button();
//        if(findDoctorsBtn.isDisplayed()) 
//        {
//        test.pass("Submit button is visible");
//        Assert.assertTrue(true);
//        }
//        else
//        {
//        test.fail("Submit button is not visible");
//        Assert.fail("test fail");
//        }
//        wait.until(ExpectedConditions.elementToBeClickable(submitBtn)).click();
//        screenshotPath = Screenshots.takeScreenShot(driver, "SubmitbuttonClicked");
//        generateReportWithScreenshot("Clicked on Book Clinic", screenshotPath);
//        
//    }
	@AfterClass(alwaysRun = true)

	public void tearDownMethod() {

		if (driver != null) {

			driver.quit();

			Reporter.log("Browser closed after test method", true);

		}

	}
}
