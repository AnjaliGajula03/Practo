package com.capgemini.parameters;

import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JsonReader {
	static String value;

	public static String  getJsonData(String jsonPath, String Key) {
   JSONParser parser = new JSONParser();
   try {
	   FileReader jsonfile = new FileReader(jsonPath);
	   Object obj = parser.parse(jsonfile);
	   JSONObject jsonObject =(JSONObject)obj;
	   value =(String) jsonObject.get(Key);
	   }
   catch(Exception e)
   {
	   System.out.println("Error reading JSON file: " + e.getMessage());
	   return null;
   }
   if(value == null) 
   {
	   System.out.println("Key not found in JSON file: " + Key);
	   return null;
   }
   else {
	   return value;
   }
  }
}