package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class patientDetails 
{
    WebDriver driver; 
    public patientDetails(WebDriver driver) {
		this.driver=driver;
	    PageFactory.initElements(driver,this);
	}
	@FindBy(xpath = "//div//label[contains(text(),'Anjali Gajula')]")
	 private WebElement Patient_Name;
	 public WebElement getPatient_Name() {
        return Patient_Name;
	 }
	 @FindBy(xpath = "//div[@data-qa-id='offline_consultation_fee']")
	 private WebElement Payment_later;
	 public WebElement getPayment_later() {
        return Payment_later;
	 }
	 @FindBy(xpath = "//button")
	 private WebElement Click_Button;
	 public WebElement getClick_Button() {
        return Click_Button;
	}
}
