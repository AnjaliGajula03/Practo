package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FD_InternalFiltersPage {
      WebDriver driver;
      WebDriverWait wait;   
      // Constructor
      
      public FD_InternalFiltersPage(WebDriver driver) {
    	  this.driver = driver;
          PageFactory.initElements(driver, this);
        }
      
        // Locators
      @FindBy(xpath = "//span//span[contains(text(),'Gender')]")
      private WebElement genderDrop;
      public WebElement getGenderDrop() {
        return genderDrop;
      }
      @FindBy(xpath = "//li//span[contains(text(),'Male Doctor')]")
      private WebElement genderSelect;
      public WebElement getGenderSelect() {
        return genderSelect;
      }
      @FindBy(xpath = "//input[@placeholder='Search doctors, clinics, hospitals, etc.']")
      private WebElement searbox;
      public WebElement getsearch() {
        return searbox;
      }
      @FindBy(xpath = "//span[@data-qa-id='selected_dropdown_filter']//span[contains(text(),'Patient Stories')]")
      private WebElement patientStoriesDrop;
      public WebElement getPatientStoriesDrop() {
        return patientStoriesDrop;
      }
      @FindBy(xpath = "//span[normalize-space()='170+ Patient Stories']")
      private WebElement storiesSelect;
      public WebElement getStoriesSelect() {
         return storiesSelect;
      }
      @FindBy(xpath = "//span[@data-qa-id='selected_dropdown_filter']//span[contains(text(),'Experience')]")
      private WebElement experience;
      public WebElement getExperience() {
        return experience;
      }
      @FindBy(xpath = "//span[normalize-space()='10+ Years of experience']")
      private WebElement experienceSelect;
      public WebElement getExperienceSelect() {
        return experienceSelect;
      }
      @FindBy(xpath = "//span[contains(text(),'All Filters')]")
      private WebElement allFilters;
      public WebElement getAllFilters() {
        return allFilters;
      }
      @FindBy(xpath = "//label[@for='Fees0']")
      private WebElement fees;
      public WebElement getFees() {
        return fees;
      }
      @FindBy(xpath = "//label[@for='Availability0']")
      private WebElement availability;
      public WebElement getAvailability() {
        return availability;
      }
      @FindBy(xpath = "//div[@data-qa-id='Consult_type_radio']")
      private WebElement consultantType;
      public WebElement getConsultantType() {
        return consultantType;
      }
      //doctors details
      @FindBy(xpath = " //h2[normalize-space()='Dr. Sheelavathi Natraj']")
      WebElement Doctors_details;
      public WebElement Doctors_details() {
        return Doctors_details;
      }
      @FindBy(xpath = "//div[3]//div[1]//div[1]//div[2]//div[1]//div[1]//div[2]//div[2]//button[1]//span[1]")
	  private WebElement ContactClinic;   
      public WebElement getContactClinic() { 
		return ContactClinic;
      }  
      @FindBy(xpath = "//div[2]//div[1]//div[2]//div[1]//div[1]//button[1]")
      WebElement Call_now;
      public WebElement getCall_now() {
        return Call_now;
      }
      //Book Clinic Visit
	  @FindBy(xpath = "(//button[contains(.,'Book Clinic Visit')])[3]")
	  private WebElement BookClinic_Visit; 
	  public WebElement getBookClinic_Visit(){
	        return BookClinic_Visit;
	    }
	  //Get slot-Day
	  @FindBy(xpath = "//div[normalize-space()='tomorrow']")
	  private WebElement Slot_Day;
	  public WebElement getSlot(){ 
	        return Slot_Day;    
	    }    	  
	  //Get slot-Time
	  @FindBy(xpath = "//span[normalize-space()='07:00 PM']")
	  private WebElement Slot_Time;
	  public WebElement getSlot_Time(){ 
	        return Slot_Time;    
	    }
}
