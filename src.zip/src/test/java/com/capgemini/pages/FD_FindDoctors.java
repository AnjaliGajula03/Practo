package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FD_FindDoctors
{
    WebDriver driver;
    public FD_FindDoctors(WebDriver driver) {
		this.driver=driver;
	    PageFactory.initElements(driver,this);
	}
	//Find Doctors
	@FindBy(xpath = "//div[@class='product-tab__title'][normalize-space()='Find Doctors']")
	private WebElement findDoctors;
	
	public WebElement getFindDoctors() {
        return findDoctors;
    }
    //Location
    @FindBy(xpath = "//input[@placeholder='Search location']") 
    private WebElement loc_textbox;
    public WebElement getLocation() {
        return loc_textbox;
    }
    
    //City
    @FindBy(xpath = "//div[normalize-space()='Jp Nagar']")
    private WebElement Select_city; 
    public WebElement getCity() {
        return Select_city;
    } 
    //SpecialiZation placeholder
    @FindBy(xpath = "//input[@placeholder='Search doctors, clinics, hospitals, etc.']")
    private WebElement specilist_box;
    public WebElement getSpecilist() {
        return specilist_box;
    }
    //SpecialiZation
    @FindBy(xpath = "//div[normalize-space()='Dermatologist']")
    private WebElement specilization;
    public WebElement getSpecilselector() {
        return specilization;
    }
    //Finding through others popular searches
    @FindBy(xpath = "//span[@class='c-popular-searches__item']")
    private WebElement PopularSearch_others;
    public WebElement getPopularSearch_others() {
        return PopularSearch_others;
    }
    //We get when we click on others
    @FindBy(xpath = "//p[normalize-space()='Dentist']")
     private WebElement Select_dentist;
    public WebElement getSelect_dentist() {
        return Select_dentist;                     
    }
}
