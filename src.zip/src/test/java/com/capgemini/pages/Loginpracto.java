package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Loginpracto {
    WebDriver driver;

    // Constructor
    public Loginpracto(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[@name='Practo login']")
    private WebElement login;
    public WebElement getLogin() {
    	return login;
    }  
    @FindBy(xpath = "//input[@id='username']")
    private WebElement logNum;
    public WebElement getLogNum() {
        return logNum;
    }
    @FindBy(xpath = "//input[@id='password']")
    private WebElement logPass;
    public WebElement getLogPass() {
        return logPass;
    }

    @FindBy(xpath = "//button[@id='login']")
    private WebElement button;
    public WebElement getButton() {
        return button;
    }
}


    
    

   

   
