package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FD_HomePage {
    WebDriver driver;

    public FD_HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[@class='product-tab__title'][normalize-space()='Find Doctors']")
    private WebElement findDoctors;

	public WebElement getFindDoctors() {
		return findDoctors;
	}
}
